# -*- coding: utf-8 -*-
# @Time    : 2021/5/3 9:58 下午
# @Author  : lichengyu
# @File    : test.py
if __name__ == '__main__':
    fields = "'aaa'"
    for i in range(1, 73):
        fields = fields + ",'aaa'"
    print(fields)
